document.addEventListener("deviceready", connectToDatabase);

var db = null;
db = window.openDatabase("tynder", "1.0", "Tynder App", 2 * 1024 * 1024);

function connectToDatabase() {
  console.log("device is ready - connecting to database");
  // 2. open the database. The code is depends on your platform!
  if (window.cordova.platformId === 'browser') {
    console.log("browser detected...");
  //  alert ("device is now ready do something");
    // For browsers, use this syntax:
      //(nameOfDb, version number, description, db size)
    // By default, set version to 1.0, and size to 2MB
//   db = window.openDatabase("Tynder", "1.0", "Tynder App",2 * 1024 * 1024);
  }
  else {
    //alert("mobile device detected");
    console.log("mobile device detected!");
    var databaseDetails = {"name":"Tynder.db", "location":"default"}
    db = window.sqlitePlugin.openDatabase(databaseDetails);
    console.log("done opening db");



  }

  if (!db) {
    alert("databse not opened!");
    return false;
  }

}

// document.getElementById("signuppress").addEventListener("click", signupnow);
//
// function signupnow() {
// alert ("sign upped ");
//   window.location.href = "signup.html";
//
// }

// ERROR MESSAGES
function onReadyTransaction( ){



		console.log("Transaction completed");
	}
	function onSuccessExecuteSql( tx, results ){
		console.log( 'Execute SQL completed' );
	}
	function onError( err ){
		console.log( err )
	}

// CREATE Users Table
db.transaction(
		function(query){
		query.executeSql(
				"CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT, password TEXT, name TEXT, Dob INTEGER, Location TEXT, Contact INTEGER, Description TEXT, Photo TEXT )",
				[],
				onSuccessExecuteSql,
				onError
			)
		},
		onError,
		onReadyTransaction
	)



  if(document.getElementById("signup-btn")){
  	document.getElementById("signup-btn").addEventListener("click", signup);

  function signup() {
    // debug:
    console.log("signup button pressed!");
  //  alert("signup button pressed!");
  	window.location.href = "signup.html";

  }
  }



  if(document.getElementById("signup-in")){
  //Sign Up Data insert
  document.getElementById("signup-in").addEventListener("click", a);

  function a() {

  	//Getting input from the sign up page
  var email = document.getElementById("email").value;
var psw = document.getElementById("psw").value;
var name = document.getElementById("name").value;
var dob = document.getElementById("dob").value;
var location = document.getElementById("location").value;

localStorage.setItem("email",email);
    // debug:
    // localStorage.setItem("email",email);
    // localStorage.setItem("name",name);
    // localStorage.setItem("dob",dob);
    // localStorage.setItem("location",location);



    console.log("signup button pressed!");

  	//Sql
  	db.transaction(
  		function(query){
  			var sql = "INSERT INTO users (email,password,name,Dob,Location) VALUES ('"+email+"','"+psw+"','"+name+"','"+dob+"','"+location+"')";
  			query.executeSql( sql,[],
  			ondbSuccessExecuteSql,
  			onError )
  		},
  		onError,
  		onReadyTransaction
  	)
  	//redirect back
  //	window.location.href = "index.html";

  }

  }
  function ondbSuccessExecuteSql( tx, results ){

    window.location.href = "index.html";

	}
if(document.getElementById("login-btn")){
	document.getElementById("login-btn").addEventListener("click", login);

function login() {
  // debug:
  console.log("login button pressed!");
//  alert("login button pressed!");

	//Getting input from the sign up page
	var email = document.getElementById("email").value;
	var psw = document.getElementById("pwd").value;

		localStorage.setItem("email",email);
		console.log(localStorage.getItem("email"));
  	//	alert(localStorage.getItem("email"));


	//Sql
	db.transaction(
		function(query){
			var sql = "SELECT id, email, password, Location FROM users where email = '"+email+"' and password ='"+psw+"' ";
			query.executeSql( sql,[],
			displayResults,
			onSuccessExecuteSql,
			onError )
		},
		onError,
		onReadyTransaction
	)






	// if count 1 then redirect home.html else login failed
	function displayResults( query, results ){

		if(results.rows.length == 0) {
			console.log("failed");
			alert("Failed");
			window.location.href = "index.html";
			return false;
		}
		else{
            localStorage.setItem("userID",results.rows[0].id);
            localStorage.setItem("userLocation",results.rows[0].Location);
			console.log("Login Successful");
			alert("Login Successful");
			window.location.href = "search.html";

		}

}
}
}

if(document.getElementById("finish")){
document.getElementById("finish").addEventListener("click",finish);

var c = document.getElementById("c").value;
var descp = document.getElementById("descp").value;
var email = localStorage.getItem("email");

function finish() {
  console.log("finish");
	console.log("email :"+email);

	//Sql
	db.transaction(
		function(query){
			var sql = "UPDATE users SET Contact = '"+c+"' where email = '"+email+"' ";

			query.executeSql( sql,[],
			onSuccessExecuteSql,
			onError )
		},
		onError,
		onReadyTransaction
	)


window.location.href = "search.html";
}
}


document.addEventListener("devcieready", doNothing);

function doNothing() {

}

if(document.getElementById("takePhotoButton")){
document.getElementById("takePhotoButton").addEventListener("click",takePhoto);

function takePhoto() {
  console.log("take photo pressed");

  // 1. choose options for the camera
  var cameraOptions = {
    quality: 50,
    destinationType: Camera.DestinationType.FILE_URI,
    encodingType: Camera.EncodingType.JPEG,
    mediaType: Camera.MediaType.PICTURE
  };

 navigator.camera.getPicture(onSuccess, onFail, cameraOptions);
}
}

function onSuccess(filename) {
  // DEBUG: Show the original file name
var imgdata = JASON.parse(filename)
  console.log("Image path: "  + filename);

  // ---------
  if (window.cordova.platformId == "android") {
    // if you are using android, you need to do some extra steps
    // to ensure you have the "real" image file path
    // Note: you need to install this plugin: cordova-plugin-filepath
    // for it to work properly
    window.FilePath.resolveNativePath(filename, function(result) {
      imageURI = result;
      console.log("Successfully converted image path: " + result);

      localStorage.setItem("photo", result);

      var image = document.getElementById("photoContainer");
      image.src = result;

    }, function (error) {
      alert("error when converting file path!");
    });
  }
  else {
    // show image in UI
    // show the image in the user interface
    var imageBox = document.getElementById("photoContainer");
    imageBox.src=filename;

    // adding it to local storage
    localStorage.setItem("photo", filename);

    // DEBUG STATEMENT
    alert(localStorage);
 }
 // -----------



  console.log("done!");

}

function onFail(errorMessage) {
  console.log("Error: " + errorMessage);
}
// geting the profile details code starts here
if(document.getElementById("profileclick")){
document.getElementById("profileclick").addEventListener("click", profilefun);

function profilefun() {


  console.log(localStorage.getItem("email"));

  userMail = localStorage.getItem("email");
    uname = localStorage.getItem("name");
    udob = localStorage.getItem("dob");
    uloc = localStorage.getItem("location");

  db.transaction(function (transaction) {

  transaction.executeSql("SELECT * FROM users where email=?", [userMail],
          function (tx, results) {

          var numRows = results.rows.length;
                  for (var i = 0; i < numRows; i++) {
          var item = results.rows.item(i);
                  console.log(item);
                  console.log(item.name);




                  document.getElementById("emailBox1").value = item.email;
                  document.getElementById("nameBox").value = item.name;
                  document.getElementById("dobBox").value = item.Dob;
                  document.getElementById("locBox").value = item.Location;
          }
          }, function (error) {

            alert ("errorrrrrrrr");
  });
  });

}

}
//user profile fetch code is completed
document.getElementById("updateeaction").addEventListener("click",updateuservalues);


var email = localStorage.getItem("email");

function updateuservalues(){


var username = document.getElementById("nameBox").value;

var useremail = document.getElementById("emailBox1").value;

var userlocation = document.getElementById("locBox").value;

var userdob = document.getElementById("dobBox").value;


// var sql = "UPDATE users SET name = '"+ username +"', Location= '"+userlocation+"', Dob='"+userdob+"' WHERE email ='" + email +"';"
// console.log(sql);

db.transaction(
  function(query){
    //var sql = "UPDATE users SET name = ?, Location=?, Dob=? WHERE email =" + email;

    var sql = "UPDATE users SET name = '"+ username +"', Location= '"+userlocation+"', Dob='"+userdob+"' WHERE email ='" + email +"';"
	
	localStorage.setItem("email",email);
    localStorage.setItem("userLocation",userlocation);

    query.executeSql( sql,[],
    onSuccessExecuteSql,
    onError )
  },
  onError,
  onReadyTransaction
)




}

document.getElementById("finishprofile").addEventListener("click",finishprofile);

function finishprofile() {
  window.location.href = "search.html";

}

//menu

document.getElementById("clicklogin").addEventListener("click", clicklogin)
function clicklogin() {
    window.location = "search.html";
}

document.getElementById("clickprofile").addEventListener("click", clickprofile)
function clickprofile() {
    window.location = "profile.html";
}

document.getElementById("clickpicture").addEventListener("click", clickpicture)
function clickpicture() {
    window.location = "pictureupload.html";
}


document.getElementById("clicksearch").addEventListener("click", clicksearch)
function clicksearch() {
    window.location = "search.html";
}

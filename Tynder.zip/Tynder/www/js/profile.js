// document.addEventListener("deviceready", connectToDatabase);
//
//
//
//
//
// function connectToDatabase() {
//   console.log("device is ready - connecting to database");
//   // 2. open the database. The code is depends on your platform!
//   if (window.cordova.platformId === 'browser') {
//     console.log("browser detected...");
//   //  alert ("device is now ready do something");
//     // For browsers, use this syntax:
//       //(nameOfDb, version number, description, db size)
//     // By default, set version to 1.0, and size to 2MB
//  //db = window.openDatabase("Tynder", "1.0", "Tynder App",2 * 1024 * 1024);  }
//   else {
//     alert("mobile device detected");
//     console.log("mobile device detected!");
//     var databaseDetails = {"name":"Tynder.db", "location":"default"}
//     db = window.sqlitePlugin.openDatabase(databaseDetails);
//     console.log("done opening db");
//
//
//
//   }
//
//   if (!db) {
//     alert("databse not opened!");
//     return false;
//   }
//
// }
//
//
//
//
// function onReadyTransaction( ){
// 		console.log( 'Transaction completed' );
//
// 		alert("Transaction completed");
// 	}
// 	function onSuccessExecuteSql( tx, results ){
// 		console.log( 'Execute SQL completed' );
// 	alert( "Execute SQL completed" );
// 	}
// 	function onError( err ){
// 		console.log( err )
// 	}
//
//   document.getElementById("profileclick").addEventListener("click",prof);
//
// function prof(){
//
//
// alert("profile opening");
//
//
//       console.log(localStorage.getItem("email"));
//
//
//
//
//
//         userMail = localStorage.getItem("email");
//         uname = localStorage.getItem("name");
//         udob = localStorage.getItem("dob");
//         uloc = localStorage.getItem("location");
//
//
//
//
//
//
//         // document.getElementById("emailBox1").innerHTML = userMail;
//         // document.getElementById("nameBox").innerHTML = uname;
//         // document.getElementById("dobBox").innerHTML = udob;
//         // document.getElementById("locBox").innerHTML = uloc;
//
//
//       db.transaction(function (transaction) {
//
//       transaction.executeSql("SELECT * FROM users where email=?", [userMail],
//               function (tx, results) {
//
//               var numRows = results.rows.length;
//                       for (var i = 0; i < numRows; i++) {
//               var item = results.rows.item(i);
//                       console.log(item);
//                       console.log(item.name);
//
//
//
//
//                       document.getElementById("emailBox1").innerHTML = item.email;
//                       document.getElementById("nameBox").innerHTML = item.name;
//                       document.getElementById("dobBox").innerHTML = item.Dob;
//                       document.getElementById("locBox").innerHTML = item.Location;
//               }
//               }, function (error) {
//
//                 alert ("errorrrrrrrr");
//       });
//       });
//
//   //window.location.href = "profile.html";
// }
// document.getElementById("updateaction").addEventListener("click",updatenow);
// function updatenow(){
//
//   alert("adasdasda");
//
//
// }
